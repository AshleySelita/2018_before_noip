#include<cstdio>
#include<cstdlib>
#include<cstring>

using namespace std;

const int maxn=5000010;
const int mo=100000007;

int n,p[maxn];

bool use[maxn];

int mul(int a,int b)
{
	int ans=1;
	while (b)
	{
		if (b&1) ans=(long long)ans*a%mo;
		a=(long long)a*a%mo;
		b>>=1;
	}
	return ans;
}

int solve(int x)
{
	int y=n,z=0;
	while (y)
	{
		y/=x;
		z+=y;
	}
	if (z&1) z--;
	return mul(x,z);
}

int main()
{
	scanf("%d",&n);
	int ans=1,cnt=0;
	for (int a=2;a<=n;a++)
	{
		if (!use[a])
		{
			cnt++;
			p[cnt]=a;
			ans=(long long)ans*solve(a)%mo;
		}
		for (int b=1;b<=cnt && a*p[b]<=n;b++)
		{
			use[a*p[b]]=true;
			if (a%p[b]==0) break;
		}
	}
	printf("%d\n",ans);

	return 0;
}
